<?
function loadsHtmlLast(){
$arrs=json_decode(file_get_contents($_SERVER["DOCUMENT_ROOT"]."/ajax/cron_info.php"),true);

$prefix = "";
for($i=0;$i<16;$i++){
$html .=<<<HTML

<div title="" class="oflo {$arrs[$i]["type"]} item{$arrs[$i]["id"]}" data-original-title="{$arrs[$i]["firstName"]}" style="display: inline-block;float: left;position: relative;width: 90px;height: 72px;padding: 1px 0px 0px;margin: 0px 15px 0px 0px;">
<img src="/img/cases/{$arrs[$i]["image"]}">
<div class="ofloname">{$arrs[$i]["fake_nickname"]}</div></div>
HTML;
}
return $html;
}

?>