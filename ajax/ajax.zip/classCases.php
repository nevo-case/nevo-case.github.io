<?PHP header("Content-Type: text/html; charset=utf-8");?>
<?

$arr["CSGO"] = array(
array("ШТЫК НОЖ M9","","milspec","4.png"),
array("AWP II ASIMOV","","milspec","5.png"),
array("СЛУЧАЙНОЕ ОРУЖИЕ","","milspec","8.png")
);
$arr["PS4"] = array(
array("ПРИСТАВКА PS4","","milspec","12.png"),
array("СЛУЧАЙНЫЙ ПРИЗ","","milspec","15.png")
);
$arr["CSGOHISTORY"] = array(
array("AWP ИСТОРИЯ О ДРАКОНЕ","","milspec","19.png"),
array("СЛУЧАЙНЫЙ ПРИЗ","","milspec","22.png")
);
$arr["GTA5"] = array(
array("STEAM КЛЮЧ GTA 5","","milspec","26.png"),
array("СЛУЧАЙНЫЙ ПРИЗ","","milspec","29.png")
);
?>